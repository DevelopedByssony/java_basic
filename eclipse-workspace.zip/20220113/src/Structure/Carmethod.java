package Structure;

public class Carmethod {

	public int gas; // 연료량
	public int speed; // 속도
	public String owner; // 차주

}
