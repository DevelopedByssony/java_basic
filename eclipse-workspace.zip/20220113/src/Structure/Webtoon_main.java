package Structure;

public class Webtoon_main {

	public static void main(String[] args) {
		Webtoon a = new Webtoon("작가1","웹툰1"); 
		Webtoon b = new Webtoon("작가2","웹툰2"); 
		a.uploadWebtoon(); 
	
	}	
}
