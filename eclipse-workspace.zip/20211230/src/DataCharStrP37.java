
public class DataCharStrP37 {

	public static void main(String[] args) {
		// 문자 자료형은 크게 두 가지로
		// 단일 문자인 char('문자')
		// 문자 배열인 String("문자열...")
		// 이 존재하며 보통 String을 주로 사용합니다.
		char a = 'a';
		String b = "문자열입니다.";
		//char c = "문자열"; // 문자열과 단일문자는
		//String d = 'd'; // 서로 다른 자료형으로 간주
		System.out.println(a);
		System.out.println(b);
	}
}
