package exception2;

public class TryCatch02P353 {

}
