package exception1;

public class Exception01P348 {
	public static void main(String[] args) {
		
	}
	
}
