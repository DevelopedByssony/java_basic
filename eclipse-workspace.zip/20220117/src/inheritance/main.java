package inheritance;

public class main {

	public static void main(String[] args) {
		Person c1 = new Person();
		c1.getInfo();

	}

}
