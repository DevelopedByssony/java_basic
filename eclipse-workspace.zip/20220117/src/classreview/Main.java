package classreview;

public class Main {

	public static void main(String[] args) {
		BasketballPlayer p1 = new BasketballPlayer(180,200);

	}

}
