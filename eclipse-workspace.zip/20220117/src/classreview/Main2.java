package classreview;

public class Main2 {

	public static void main(String[] args) {
		Car c1 = new Car("�̸�");
		c1.getInfor();
	}

}
