
public class star {
	public static void main(String[] args) {
		int star, j;
		for (j=0; j<7; j++)
		{ 
			{
				for (star = 0; star <= j; star++)
					System.out.print("*");
			}
		}
	}
}
