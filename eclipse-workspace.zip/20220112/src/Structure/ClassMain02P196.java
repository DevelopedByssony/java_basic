package Structure;

public class ClassMain02P196 {

	public static void main(String[] args) {
		// 차 2대 생성
		Car a = new Car();
		a.name = "채종훈";
		a.age = 20;
		a.pNum = "01012345678";
		System.out.println(a);
		
		Car b = new Car();
		b.name = "김자바";
		b.age = 10;
		b.pNum = "01011111111";
		System.out.println(b);

	}
