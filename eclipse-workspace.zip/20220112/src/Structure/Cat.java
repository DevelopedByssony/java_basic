package Structure;

public class Cat {
	public String nname;
	public int aage;
	public String ppNum;
	}
