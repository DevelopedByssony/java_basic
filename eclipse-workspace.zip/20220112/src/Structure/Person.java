package Structure;

public class Person {
	public String name;
	public int age;
	public String pNum;
	public String address;
}
