package accessmodifier;

public class DogMain {

	public static void main(String[] args) {
		Dog d1 = new Dog("멍멍이");
		d1.feed();
		d1.feed();
		d1.feed();
	}
}
